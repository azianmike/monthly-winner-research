from pathlib import Path
import json
root=Path(__file__).parent
p=Path('/tmp/backtest-workbook/build.mjs');s=p.read_text()
replacements={
"/outputs/backtest_1998'":"/outputs/final_backtest'",
"Fixed selections from the public-data run.":"Fixed selections from the finalized approximate run.",
"['Stale marks'":"['Write-offs at cost'",
"'Stale marks'":"'Write-offs at cost'",
"'Stale value per $1'":"'Write-off cost per $1'",
"x.stale_holdings_value/1000":"x.written_off_cost/1000",
"Order reflects the original run. An ended price series is carried at its final quote; actual recovery is unresolved.":"Ended or unavailable histories are valued at $0, including acquired companies. No recovery is credited.",
"Result status: unreliable public-data illustration":"Finalized approximation: ended histories valued at $0",
"['Holdings with ended price series']":"['Stocks valued at $0']",
"Largest holdings in the illustration":"Largest holdings in the finalized model",
"Split anomalies remain in USB and PBG. Actual merger and spin-off holdings are unresolved.":"Ended histories are written off at $0. Extra split multipliers were corrected under documented assumptions.",
"The ending value cannot establish what the complete strategy would have earned.":"Missing candidates are omitted from rankings, so this is an approximate historical-universe test.",
"Provisional portfolio values":"Portfolio values under the $0 rule",
"73 purchased tickers end before the terminal valuation date. Their final recorded adjusted prices are carried forward, totaling about $233,634. This is not a verified cash payout or recovery.":"User rule: a bought security without a quote through October 9, 2026 is worth $0. Its entire $1,000 purchase is lost. This includes acquired companies and inaccessible histories; no merger payout or successor stock is credited. See Holdings and Purchases for every write-off.",
"No separate ownership ledger for spin-offs or stock-for-stock mergers. Total-return price conventions can reinvest those distributions in the parent. This is not the strict never-sell ownership path.":"Reinvested distributions follow the adjusted-price convention. Inaccessible successor stocks and acquired-company series are assigned $0 under the user rule. Spin-off returns use the provider convention rather than a separate child-share ledger.",
"USB-200102: 3× split factor on 1999-04-16 while the raw close barely changes. PBG-201002: 2× split factor on consecutive days in December 2001. These affect selected winners. Both remain uncorrected.":"Extra split factors were removed when raw prices did not show the mechanical split move and no offsetting adjacent-day event explained it. Four records are documented in split_corrections.csv, including USB and PBG. Monthly winners were reranked after cleaning.",
"['Definitive data requirement','Licensed CRSP or an equivalent complete survivor-free database, official historical membership, permanent security identifiers, and verified merger, spin-off, bankruptcy and delisting records.']":"['Remaining limitation','Unobservable candidate returns are omitted from selection. Writing off purchased unavailable histories does not resolve missing candidate stocks. A complete licensed universe could change picks and outcomes. The requested approximate model is finalized under this explicit fallback.']"
}
for a,b in replacements.items():
    if a not in s: print('Optional text not found:',a[:45])
    s=s.replace(a,b)
s=s.replace("summary.getRange('B18').values", "summary.getRange('B17').values=[['Write-off purchases (initial cost)']];summary.getRange('C17').values=[[data.summary.writeoff_initial_cost]];summary.getRange('C17').setNumberFormat(fmtMoney);\nsummary.getRange('B18').values")
p.write_text(s)
p=root/'create_chart.py';s=p.read_text().replace("'outputs/backtest_1998'","'outputs/final_backtest'")
s=s.replace('Monthly winner strategy: provisional public-data run','Buy monthly winners and hold: $0 write-off rule').replace('Available-history leaders (unreliable estimate)','Monthly winners (available-price universe)')
s=s.replace('Not a complete historical backtest. Missing prices can change the monthly winner. Apparent split errors remain.\\n73 holdings use stale final quotes. Merger and spin-off share ownership is not fully reconstructed.','Ended or unavailable purchased securities are valued at $0, including acquired companies.\\nMissing candidates are omitted from rankings. This approximate result depends heavily on a few winners.')
s=s[:s.index('issues=[')]+"print('Final chart created.')\n"
p.write_text(s)
data=json.loads((root/'outputs/final_backtest/summary.json').read_text())
text=f'''FINAL APPROXIMATE BACKTEST UNDER USER-AUTHORIZED ASSUMPTIONS

January 2, 1998 through October 9, 2026. $1,000 new money monthly.
346 contributions; $346,000 invested. Never voluntarily sell a purchase.
Rank prior-month total returns among then-current S&P 500 members with usable
prices, buy at the following month's first trading-day open, and reinvest
distributions. Repeated winners get a fresh $1,000 investment.

FINAL RESULTS
Monthly winners: ${data['strategy_marked_value']:,.2f}.
Matched monthly SPY purchases: ${data['spy_value']:,.2f}.
Money-weighted annual returns: {data['strategy_xirr']:.2%} vs {data['spy_xirr']:.2%}.
Every deposit and terminal value is included in the cash-flow IRR.

ZERO RULE
A bought company with no price through the terminal date is assigned $0,
including acquired, delisted, bankrupt and otherwise unavailable series.
No cash merger payout or successor stock is credited. Each affected purchase
loses the ENTIRE original $1,000, not merely the last recorded asset value.
{data['writeoff_lots']} purchase lots in {data['stale_holdings_count']} stocks are written off.
Initial cost of those lots: ${data['writeoff_initial_cost']:,.0f}.
For the historical path the asset is written off after its final quoted date,
not retroactively at purchase using knowledge of a later disappearance.

REASONABLE DATA FALLBACKS
Unpriced candidates are omitted from ranking and the best observable eligible
stock is selected. This fallback is material: {data['missing_ranking_months']} of 346 rankings
are incomplete. The zero rule for BOUGHT companies does not recover the true
winner among missing candidates. This is a finalized approximation, not an
unbiased full-universe result or a guarantee of conservative overall returns.
Four apparent duplicate/unpaired split records were corrected by removing
the extra split multiplier. Proper mechanically reflected splits and merely
shifted adjacent-day events were retained. See split_corrections.csv.
Fractional shares, reinvested distributions, no taxes or trading costs. SPY
fund fees are embedded. In-kind spin-off returns follow provider adjustments.

ANALYSIS
Apple and Nvidia represent {data['top2_weight']:.1%} of ending value. Only
{data['winner_lots_beat_spy']} of 346 lots beat their matched SPY deposits. Huge long-run winners
drive the portfolio, so this run does not establish broadly repeatable skill.

SENSITIVITY
The secondary model writes off the entire monthly deposit whenever ANY
candidate cannot be ranked. It ends at ${data['harsh_missing_ranking_value']:,.2f} versus the
same ${data['spy_value']:,.2f} SPY benchmark. This deliberately harsh assumption is a
stress test, not a bound on the true result. Another row uses only complete
ranking months with a matched smaller contribution schedule; do not compare
that row's dollar value with the original 346-deposit benchmark.

SOURCES
https://github.com/Johnbrick123/sp500-data/releases/tag/data
https://github.com/fja05680/sp500
The input snapshots were downloaded October 12, 2026 and end October 9, 2026.
Source and frozen-input hashes are retained. SPY, AAPL, NVDA and MU were
cross-checked with Yahoo history in the initial audit. No live data is required
to reproduce this final run.

REPRODUCE
Unzip, then run: python finalize_backtest.py
Requires numpy, pandas and scipy. Uses frozen inputs in outputs/backtest_1998
and regenerates final results in outputs/final_backtest. No network required.
run_backtest.py supports the earlier illustrative model; the finalized output
is produced by finalize_backtest.py. The workbook deposit input rescales the
fixed purchase ledger but does not rerank stocks when prices are changed.

VALIDATION
346 equal dated deposits, signals strictly before purchase, zero valuations
for every written-off purchase, and independent lot/portfolio/benchmark
reconciliation within one cent. Workbook formula and scaling checks are run
again for the finalized values. Frozen-input reproduction is tested separately.
'''
(root/'outputs/final_backtest/README.txt').write_text(text)
print('Final artifact sources updated.')
