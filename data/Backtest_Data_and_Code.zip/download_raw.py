import urllib.request,json,pathlib
root=pathlib.Path(__file__).parent/'data'
req=urllib.request.Request('https://api.github.com/repos/Johnbrick123/sp500-data/releases/tags/data',headers={'User-Agent':'historical-stock-backtest'})
o=json.load(urllib.request.urlopen(req,timeout=30))
(root/'live_release.json').write_text(json.dumps(o))
for a in o['assets']:
    if a['name'] in ['raw.tar.zst','renames.csv','wiki_report.txt','no_data_tickers.txt','delisted_suffix_tickers.txt','verification_report.txt']:
        print(a['name'],a['size'],flush=True)
        p=root/('live_'+a['name'])
        with urllib.request.urlopen(urllib.request.Request(a['browser_download_url'],headers={'User-Agent':'historical-stock-backtest'}),timeout=60) as r, p.open('wb') as f:
            while True:
                b=r.read(1048576)
                if not b:break
                f.write(b)
        print('downloaded',a['name'],flush=True)
