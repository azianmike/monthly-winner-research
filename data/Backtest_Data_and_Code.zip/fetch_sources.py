import urllib.request, urllib.parse, json, concurrent.futures, pathlib
ROOT=pathlib.Path(__file__).parent
jobs=[
('membership.csv','https://raw.githubusercontent.com/fja05680/sp500/master/'+urllib.parse.quote('S&P 500 Historical Components & Changes (Updated).csv')),
('public_dataset_readme.md','https://raw.githubusercontent.com/Johnbrick123/sp500-data/main/README.md'),
('teddy_readme.md','https://raw.githubusercontent.com/teddykoker/survivorship-free-spy/master/survivorship-free/README.md'),
('teddy_prices.zip','https://raw.githubusercontent.com/teddykoker/survivorship-free-spy/master/survivorship-free/data.zip'),
('teddy_constituents.csv','https://raw.githubusercontent.com/teddykoker/survivorship-free-spy/master/survivorship-free/constituents.csv'),
('public_releases.json','https://api.github.com/repos/Johnbrick123/sp500-data/releases/latest'),
]
def fetch(job):
    name,url=job
    p=ROOT/'data'/name
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'historical-stock-backtest'})
        with urllib.request.urlopen(req,timeout=60) as response: p.write_bytes(response.read())
        print(name,p.stat().st_size,flush=True)
        if name.endswith('readme.md'): print(p.read_text()[:10000],flush=True)
        if name.endswith('.json'):
            o=json.loads(p.read_text()); print([(x['name'],x['size'],x['browser_download_url']) for x in o.get('assets',[])],flush=True)
    except Exception as e: print(name,type(e).__name__,str(e),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool: list(pool.map(fetch,jobs))
