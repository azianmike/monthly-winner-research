import urllib.request,urllib.parse,json,concurrent.futures,pathlib
import pandas as pd,numpy as np
from parquet_reader import read
root=pathlib.Path(__file__).parent
def yahoo(ticker):
    url=f'https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(ticker)}?period1=880934400&period2=1791676800&interval=1d&events=div%2Csplits'
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
    o=json.load(urllib.request.urlopen(req,timeout=40))['chart']['result'][0]
    (root/'data'/f'yahoo_{ticker}.json').write_text(json.dumps(o))
    d=pd.DataFrame(o['indicators']['quote'][0]);d['date']=pd.to_datetime(o['timestamp'],unit='s',utc=True).tz_convert('America/New_York').tz_localize(None).normalize();d['adj_close']=o['indicators']['adjclose'][0]['adjclose']
    reference=pd.read_pickle(root/'data/live_prices.pkl');reference=reference[reference.ticker==ticker]
    c=reference.merge(d,on='date',suffixes=('_dataset','_yahoo'))
    cr=(c.adj_close_dataset.iloc[-1]/c.adj_close_dataset.iloc[0])/(c.adj_close_yahoo.iloc[-1]/c.adj_close_yahoo.iloc[0])-1
    err=(c.close_dataset/c.close_yahoo-1).abs().max()
    print(ticker,'dates',str(c.date.iloc[0].date()),str(c.date.iloc[-1].date()),'terminal close',c.close_yahoo.iloc[-1],'max close relative error',err,'total-return-factor relative error',cr,flush=True)
    return {'ticker':ticker,'first':str(c.date.iloc[0].date()),'last':str(c.date.iloc[-1].date()),'max_close_relative_error':float(err),'return_factor_relative_error':float(cr)}
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:
    for t,r in zip(['SPY','AAPL','NVDA','MU'],p.map(yahoo,['SPY','AAPL','NVDA','MU'])):results.append(r)
(root/'outputs/backtest_1998/validation.json').write_text(json.dumps(results,indent=2))
full=read(root/'data/live_prices.parquet',['date','ticker','close','adj_close','dividends','stock_splits','source'])
for t,lo,hi in [('USB-200102','1999-03-01','1999-05-10'),('PBG-201002','2001-11-01','2002-01-10'),('AIG','2009-07-01','2009-09-10')]:
    d=full[(full.ticker==t)&(full.date>=lo)&(full.date<=hi)].copy();d['ret']=d.adj_close.pct_change();print(t,d.sort_values('ret',ascending=False).head(6).to_string(index=False),flush=True)
