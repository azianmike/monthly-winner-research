from pathlib import Path
import json,hashlib,zipfile,shutil
root=Path(__file__).parent;out=root/'outputs/backtest_1998'
shutil.copyfile('/tmp/backtest-workbook/build.mjs',out/'build.mjs')
shutil.copyfile(root/'data/live_verification_report.txt',out/'source_verification_report.txt')
release=json.loads((root/'data/live_release.json').read_text())
metadata={'source_url':'https://github.com/Johnbrick123/sp500-data/releases/tag/data','downloaded_utc':'2026-10-12','release_id':release['id'],'release_published_at':release.get('published_at'),'source_price_end':'2026-10-09'}
(out/'source_metadata.json').write_text(json.dumps(metadata,indent=2))
frozen={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'price_endpoints.csv',out/'price_marks.csv',out/'terminal_quotes.csv',out/'membership_intervals.csv']}
(out/'frozen_input_hashes.json').write_text(json.dumps(frozen,indent=2))
target=out/'Backtest_Data_and_Code.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    z.write(out/'README.txt','README.txt')
    for p in root.glob('*.py'):z.write(p,p.name)
    z.write(out/'build.mjs','build.mjs')
    for p in out.iterdir():
        if p.suffix in ['.csv','.json','.txt'] and p.name!='README.txt':z.write(p,str(p.relative_to(root)))
print('Archive bytes:',target.stat().st_size)
