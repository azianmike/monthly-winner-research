"""Minimal flat Parquet reader using the runtime's standard libraries.

Supports the plain/dictionary encoded, Snappy/Zstd compressed scalar columns
used by the public backtest input. Fails explicitly on unsupported encodings.
Apache Parquet format: https://github.com/apache/parquet-format
"""
import struct, ctypes, ctypes.util, math, pathlib
import numpy as np
import pandas as pd

class Compact:
    def __init__(self,b,pos=0): self.b,self.p=b,pos
    def var(self):
        n=s=0
        while True:
            v=self.b[self.p]; self.p+=1; n|=(v&127)<<s
            if v<128:return n
            s+=7
    def sint(self):
        n=self.var();return (n>>1)^-(n&1)
    def value(self,t):
        if t==1:return True
        if t==2:return False
        if t==3:
            v=self.b[self.p];self.p+=1;return v
        if t in (4,5,6):return self.sint()
        if t==7:
            v=struct.unpack_from('<d',self.b,self.p)[0];self.p+=8;return v
        if t==8:
            n=self.var();v=self.b[self.p:self.p+n];self.p+=n;return v
        if t in (9,10):
            h=self.b[self.p];self.p+=1;n=h>>4
            if n==15:n=self.var()
            return [self.value(h&15) for _ in range(n)]
        if t==11:
            n=self.var()
            if not n:return {}
            h=self.b[self.p];self.p+=1
            return {self.value(h>>4):self.value(h&15) for _ in range(n)}
        if t==12:return self.obj()
        raise ValueError(('unknown compact type',t))
    def obj(self):
        o={};last=0
        while True:
            h=self.b[self.p];self.p+=1
            if h==0:return o
            field=last+(h>>4) if h>>4 else self.sint()
            o[field]=self.value(h&15);last=field

_snappy=ctypes.CDLL(ctypes.util.find_library('snappy'))
_snappy.snappy_uncompress.argtypes=[ctypes.c_char_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t)]
def decompress(b,codec,size):
    if codec==0:return b
    if codec==1:
        out=ctypes.create_string_buffer(size);n=ctypes.c_size_t(size)
        status=_snappy.snappy_uncompress(b,len(b),out,ctypes.byref(n))
        if status!=0 or n.value!=size:raise ValueError('invalid snappy page')
        return out.raw
    if codec==2:
        import gzip
        return gzip.decompress(b)
    if codec==6:
        import zstandard
        return zstandard.ZstdDecompressor().decompress(b,max_output_size=size)
    raise ValueError(('unsupported compression',codec))

def plain(b,t,n):
    dt={0:None,1:'<i4',2:'<i8',4:'<f4',5:'<f8'}
    if t in dt and t!=0:return np.frombuffer(b,dtype=dt[t],count=n).copy()
    if t==6:
        out=[];p=0
        for _ in range(n):
            z=struct.unpack_from('<I',b,p)[0];p+=4
            out.append(b[p:p+z].decode());p+=z
        return np.array(out,dtype=object)
    if t==0:return np.unpackbits(np.frombuffer(b,dtype=np.uint8),bitorder='little')[:n].astype(bool)
    raise ValueError(('unsupported plain type',t))

def hybrid(b,bw,n):
    if bw==0:return np.zeros(n,dtype=np.int32)
    p=0;parts=[];total=0
    while total<n:
        r=Compact(b,p);h=r.var();p=r.p
        if h&1:
            count=(h>>1)*8;size=count*bw//8
            bits=np.unpackbits(np.frombuffer(b[p:p+size],dtype=np.uint8),bitorder='little').reshape(count,bw)
            arr=(bits*(1<<np.arange(bw,dtype=np.int64))).sum(axis=1,dtype=np.int64).astype(np.int32);p+=size
        else:
            count=h>>1;size=(bw+7)//8
            v=int.from_bytes(b[p:p+size],'little');p+=size
            arr=np.full(count,v,dtype=np.int32)
        parts.append(arr);total+=count
    return np.concatenate(parts)[:n]

def read(path,columns=None):
    b=pathlib.Path(path).read_bytes()
    if b[:4]!=b'PAR1' or b[-4:]!=b'PAR1':raise ValueError('not parquet')
    size=struct.unpack_from('<I',b,len(b)-8)[0]
    meta=Compact(b,len(b)-8-size).obj()
    schema={s[4].decode():s for s in meta[2][1:]}
    result={name:[] for name in schema if columns is None or name in columns}
    for group in meta[4]:
        for chunk in group[1]:
            cm=chunk[3];name=cm[3][-1].decode()
            if name not in result:continue
            s=schema[name];maxdef=1 if s.get(3)==1 else 0
            pos=min(cm.get(11,cm[9]),cm[9]);count=0;dictionary=None;out=[]
            while count<cm[5]:
                r=Compact(b,pos);h=r.obj();pos=r.p
                data=b[pos:pos+h[3]];pos+=h[3]
                data=decompress(data,cm[4],h[2])
                if h[1]==2:
                    dictionary=plain(data,cm[1],h[7][1]);continue
                if h[1]!=0:raise ValueError(('unsupported page type',h[1],name))
                dh=h[5];n=dh[1];off=0
                if maxdef:
                    length=struct.unpack_from('<I',data,0)[0]
                    defs=hybrid(data[4:4+length],1,n);off=4+length
                else:defs=np.ones(n,dtype=np.int32)
                valid=defs==maxdef if maxdef else defs==1
                nn=int(valid.sum());enc=dh[2]
                if enc==0:values=plain(data[off:],cm[1],nn)
                elif enc in (2,8):
                    if dictionary is None:raise ValueError('missing dictionary')
                    ids=hybrid(data[off+1:],data[off],nn);values=dictionary[ids]
                else:raise ValueError(('unsupported value encoding',enc,name))
                if not valid.all():
                    dtype=object if values.dtype==object else np.float64
                    full=np.full(n,None if dtype==object else np.nan,dtype=dtype);full[valid]=values;values=full
                out.append(values);count+=n
            if count!=group[3]:raise ValueError(('row-count mismatch',name,count,group[3]))
            result[name].append(np.concatenate(out))
    frame=pd.DataFrame({name:np.concatenate(parts) for name,parts in result.items()})
    if len(frame)!=meta[3]:raise ValueError('file row-count mismatch')
    for name in frame.columns:
        s=schema[name]
        if s.get(6)==6:frame[name]=pd.to_datetime(frame[name],unit='D')
        elif s.get(6) in (9,10):frame[name]=pd.to_datetime(frame[name],unit='ms' if s[6]==9 else 'us')
        elif 10 in s and 8 in s[10]:
            unit=s[10][8][2]
            u='ms' if 1 in unit else 'us' if 2 in unit else 'ns'
            frame[name]=pd.to_datetime(frame[name],unit=u)
    return frame

if __name__=='__main__':
    import sys
    d=read(sys.argv[1]);print(d.shape,d.dtypes.to_string());print(d.head(3).to_string(index=False));print(d.tail(3).to_string(index=False))
