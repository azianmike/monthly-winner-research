import urllib.request, json, concurrent.futures

def get_repo(repo):
    req=urllib.request.Request(f'https://api.github.com/repos/{repo}/git/trees/HEAD?recursive=1',headers={'User-Agent':'research-backtest'})
    try:
        obj=json.load(urllib.request.urlopen(req,timeout=30))
        print(repo, json.dumps([(x['path'],x.get('size')) for x in obj.get('tree',[]) if x.get('type')=='blob'][:140]))
    except Exception as e: print(repo,str(e))

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    list(pool.map(get_repo,['teddykoker/survivorship-free-spy','Johnbrick123/sp500-data','fja05680/sp500','joeyfife/point-in-time-sp500']))
