from pathlib import Path
import json
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import matplotlib.dates as mdates

out=Path(__file__).parent/'outputs/final_backtest'
d=pd.read_csv(out/'monthly_results.csv',parse_dates=['date'])
s=json.loads((out/'summary.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,(ax,cov)=plt.subplots(2,1,figsize=(11.8,8.2),sharex=True,gridspec_kw={'height_ratios':[3,1],'hspace':0.22})
fig.patch.set_facecolor('#fafafa')
fig.suptitle('Buy monthly winners and hold: $0 write-off rule',x=.08,ha='left',fontsize=19,fontweight='bold',y=.965)
fig.text(.08,.92,'$1,000 each month from January 1998 through October 9, 2026. Dividends reinvested.',fontsize=11,color='#454545')
ax.plot(d.date,d.strategy_marked_value,color='#ba641d',lw=2.5,label='Monthly winners (available-price universe)')
ax.plot(d.date,d.spy_value,color='#235a99',lw=2.4,label='S&P 500 via SPY')
ax.plot(d.date,d.cumulative_contributions,color='#838383',lw=1.6,ls='--',label='Contributions')
ax.yaxis.set_major_formatter(mtick.FuncFormatter(lambda v,p:f'${v/1e6:.0f}M'))
ax.set_ylabel('Portfolio value')
ax.set_xlim(d.date.iloc[0],pd.Timestamp('2027-01-01'))
ax.grid(axis='y',alpha=.18)
ax.legend(loc='upper left',frameon=False,fontsize=10)
ax.annotate(f"${s['strategy_marked_value']/1e6:.2f}M",xy=(d.date.iloc[-1],s['strategy_marked_value']),xytext=(-8,12),textcoords='offset points',ha='right',color='#ba641d',fontweight='bold')
ax.annotate(f"${s['spy_value']/1e6:.2f}M",xy=(d.date.iloc[-1],s['spy_value']),xytext=(-8,12),textcoords='offset points',ha='right',color='#235a99',fontweight='bold')
cov.fill_between(d.date,d.coverage*100,100,color='#ebd1c0',alpha=.8,label='Missing prices')
cov.plot(d.date,d.coverage*100,color='#695849',lw=1.6)
cov.set_ylim(0,105);cov.set_yticks([0,50,100]);cov.yaxis.set_major_formatter(mtick.PercentFormatter())
cov.set_ylabel('Members ranked');cov.grid(axis='y',alpha=.18)
cov.xaxis.set_major_locator(mdates.YearLocator(4));cov.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
cov.text(.015,.16,'Only 54% of members could be ranked in 1998',transform=cov.transAxes,color='#6b3420',fontsize=10)
fig.text(.08,.035,'Ended or unavailable purchased securities are valued at $0, including acquired companies.\nMissing candidates are omitted from rankings. This approximate result depends heavily on a few winners.',fontsize=10,color='#843923',linespacing=1.6)
fig.subplots_adjust(left=.08,right=.96,top=.875,bottom=.14)
fig.savefig(out/'backtest_comparison.png',dpi=160,facecolor=fig.get_facecolor())
print('Final chart created.')
