"""Auditable public-data illustration, NOT an unbiased historical backtest.

$1,000 monthly from January 1998. Rank previous-calendar-month total returns
among then-current S&P 500 members with complete endpoint prices. Buy the
observed leader at the following month's first trading-day adjusted open.
Retain all positions. Compare identical cash flows invested in SPY.
Missing historical prices mean the true winner is not always identifiable.
"""
from pathlib import Path
import json, hashlib, math
import sys
import numpy as np
import pandas as pd
from scipy.optimize import brentq

ROOT=Path(__file__).parent
OUT=ROOT/'outputs'/'backtest_1998'
OUT.mkdir(parents=True,exist_ok=True)
AMOUNT=1000.0
START=pd.Timestamp('1998-01-01')
ASOF=pd.Timestamp('2026-10-09')

def xirr(dates,flows):
    days=(pd.DatetimeIndex(dates)-pd.Timestamp(dates[0])).days.to_numpy()/365.25
    c=np.asarray(flows,dtype=float)
    f=lambda lr:float(np.sum(c*np.exp(-lr*days)))
    return math.exp(brentq(f,-10,10))-1

def main():
    saved='--saved-inputs' in sys.argv
    if not saved:
        from parquet_reader import read
    cache=ROOT/'data'/'live_prices.pkl'
    if saved:
        prices=pd.read_csv(OUT/'price_endpoints.csv',parse_dates=['date'])[['date','ticker','open','close','adj_close']]
    else:
        prices=pd.read_pickle(cache) if cache.exists() else read(ROOT/'data'/'live_prices.parquet',['date','ticker','open','close','adj_close'])
        if not cache.exists():prices.to_pickle(cache)
    prices=prices[(prices.date<=ASOF)&(prices.date>='1997-11-01')].copy()
    assert not prices.duplicated(['date','ticker']).any()
    assert (prices[['open','close','adj_close']]>0).all().all()
    intervals=pd.read_csv(OUT/'membership_intervals.csv',parse_dates=['start','end']) if saved else read(ROOT/'data'/'live_membership_intervals.parquet')
    intervals.to_csv(OUT/'membership_intervals.csv',index=False)
    spy=prices[prices.ticker=='SPY'].set_index('date').sort_index()
    days=spy.index
    months=pd.period_range(START,ASOF,freq='M')
    month_dates={}
    for period in pd.period_range('1997-11',ASOF,freq='M'):
        trading=days[days.to_period('M')==period]
        if len(trading):month_dates[period]=(trading[0],trading[-1])
    endpoints=sorted(set(d for pair in month_dates.values() for d in pair))
    panel=prices[prices.date.isin(endpoints)].copy()
    panel['adj_open']=panel.open*panel.adj_close/panel.close
    panel.to_csv(OUT/'price_endpoints.csv',index=False,float_format='%.12g')
    close=panel.pivot(index='date',columns='ticker',values='adj_close').sort_index()
    op=panel.pivot(index='date',columns='ticker',values='adj_open').sort_index()
    last=pd.read_csv(OUT/'terminal_quotes.csv',parse_dates=['date']).set_index('ticker') if saved else prices.groupby('ticker',sort=False).tail(1).set_index('ticker')
    if not saved:last.reset_index().to_csv(OUT/'terminal_quotes.csv',index=False,float_format='%.12g')
    positions=pd.Series(0.0,index=close.columns)
    spyunits=0.0;uninvested=0.0;fund_units=0.0;fund_nav=1.0;previous_nav=1.0
    rows=[];lots=[];ranking_rows=[];unresolved=[]
    # Carry a dead series' actual final daily quote, rather than the preceding
    # month-end quote. Reconcile this separately to lot-level terminal values.
    if saved:
        close_filled=pd.read_csv(OUT/'price_marks.csv',index_col=0,parse_dates=[0])
    else:
        close_filled=prices.pivot(index='date',columns='ticker',values='adj_close').sort_index().ffill().reindex(endpoints)
        close_filled.to_csv(OUT/'price_marks.csv',float_format='%.12g')
    for k,month in enumerate(months):
        buy,end=month_dates[month]
        signal=month_dates[month-1][1];base=month_dates[month-2][1]
        member=intervals[(intervals.start<=signal)&(intervals.end.isna()|(intervals.end>signal))].ticker.unique()
        members=set(member)
        existing=sorted(members&set(close.columns))
        ret=(close.loc[signal,existing]/close.loc[base,existing]-1).dropna()
        ret=ret.sort_values(ascending=False,kind='stable')
        missing=sorted(members-set(ret.index))
        for rank,(ticker,r) in enumerate(ret.items(),1):
            ranking_rows.append({'signal_date':signal.date().isoformat(),'ticker':ticker,'rank':rank,'total_return':float(r)})
        winner=str(ret.index[0]);wr=float(ret.iloc[0])
        entry=float(op.loc[buy,winner])
        # No runner-up substitution based on future quote availability.
        executable=np.isfinite(entry) and entry>0
        current_open=op.loc[buy].fillna(close_filled.loc[buy])
        before=float((positions*current_open.fillna(0)).sum())+uninvested
        if k==0:fund_units=AMOUNT
        else:
            nav_before=before/fund_units
            fund_units+=AMOUNT/nav_before
        if executable:
            units=AMOUNT/entry;positions[winner]+=units
        else:
            units=0.0;uninvested+=AMOUNT
            unresolved.append({'buy_date':buy.date().isoformat(),'ticker':winner,'issue':'Winning observed stock has no next-open quote; contribution held as cash for illustration.'})
        spyentry=float(op.loc[buy,'SPY']);spyunits+=AMOUNT/spyentry
        value=float((positions*close_filled.loc[end].fillna(0)).sum())+uninvested
        benchmark=spyunits*float(close.loc[end,'SPY'])
        fund_nav=value/fund_units
        twr=fund_nav/previous_nav-1;previous_nav=fund_nav
        # Stale holdings are marked at their last recorded adjusted price.
        # This is an explicit valuation convention, not a resolved cash payout.
        active=positions[positions>0].index
        stale=[t for t in active if last.loc[t,'date']<end-pd.Timedelta(days=14)]
        stale_value=float((positions.loc[stale]*close_filled.loc[end,stale]).sum()) if stale else 0.0
        lotfinal=units*float(last.loc[winner,'adj_close']) if executable else AMOUNT
        status='current price' if last.loc[winner,'date']>=ASOF-pd.Timedelta(days=14) else 'unresolved end of history'
        lots.append({'buy_date':buy.date().isoformat(),'signal_date':signal.date().isoformat(),'ticker':winner,'previous_month_return':wr,'entry_adj_open':entry if executable else None,'contribution':AMOUNT,'adjusted_units':units,'last_price_date':last.loc[winner,'date'].date().isoformat(),'last_adj_close':float(last.loc[winner,'adj_close']),'ending_marked_value':lotfinal,'spy_entry_adj_open':spyentry,'spy_final_adj_close':float(close.loc[ASOF,'SPY']),'spy_ending_value':AMOUNT*float(close.loc[ASOF,'SPY'])/spyentry,'status':status})
        rows.append({'date':end.date().isoformat(),'buy_date':buy.date().isoformat(),'winner':winner,'previous_month_return':wr,'members':len(members),'ranked_members':len(ret),'coverage':len(ret)/len(members),'missing_tickers':';'.join(missing),'contribution':AMOUNT,'cumulative_contributions':AMOUNT*(k+1),'strategy_marked_value':value,'spy_value':benchmark,'stale_holdings_value':stale_value,'strategy_return_index':fund_nav,'strategy_monthly_twr':twr,'spy_return_index':float(close.loc[end,'SPY'])/float(op.loc[month_dates[months[0]][0],'SPY'])})
    monthly=pd.DataFrame(rows);l=pd.DataFrame(lots)
    holdings=l.groupby('ticker').agg(purchases=('contribution','size'),invested=('contribution','sum'),marked_value=('ending_marked_value','sum'),last_price_date=('last_price_date','max'),status=('status','first')).reset_index().sort_values('marked_value',ascending=False)
    holdings['portfolio_weight']=holdings.marked_value/monthly.strategy_marked_value.iloc[-1]
    annual=monthly.groupby(pd.to_datetime(monthly.date).dt.year).agg(contributions=('contribution','sum'),total_invested=('cumulative_contributions','last'),strategy_marked_value=('strategy_marked_value','last'),spy_value=('spy_value','last'),mean_coverage=('coverage','mean'),minimum_coverage=('coverage','min'),stale_holdings_value=('stale_holdings_value','last')).reset_index().rename(columns={'date':'year'})
    total=float(monthly.strategy_marked_value.iloc[-1]);benchmark=float(monthly.spy_value.iloc[-1]);stale=float(monthly.stale_holdings_value.iloc[-1])
    top=holdings.iloc[0]
    summary={'status':'PUBLIC-DATA ILLUSTRATION; NOT A COMPLETE SURVIVORSHIP-FREE BACKTEST','start':str(START.date()),'as_of':str(ASOF.date()),'monthly_contribution':AMOUNT,'purchases':len(monthly),'contributed':len(monthly)*AMOUNT,'strategy_marked_value':total,'spy_value':benchmark,'strategy_profit':total-len(monthly)*AMOUNT,'spy_profit':benchmark-len(monthly)*AMOUNT,'strategy_xirr':xirr(list(l.buy_date)+[ASOF],[-AMOUNT]*len(l)+[total]),'spy_xirr':xirr(list(l.buy_date)+[ASOF],[-AMOUNT]*len(l)+[benchmark]),'stale_holdings_value':stale,'stale_holdings_count':int((holdings.status=='unresolved end of history').sum()),'strategy_with_stale_zero':total-stale,'mean_price_coverage':float(monthly.coverage.mean()),'minimum_price_coverage':float(monthly.coverage.min()),'full_coverage_months':int((monthly.ranked_members==monthly.members).sum()),'unique_bought_stocks':len(holdings),'top_holding':str(top.ticker),'top_holding_value':float(top.marked_value),'top_holding_weight':float(top.portfolio_weight),'winner_lots_below_cost':int((l.ending_marked_value<l.contribution).sum()),'winner_lots_beat_spy':int((l.ending_marked_value>l.spy_ending_value).sum()),'missing_entry_count':len(unresolved),'limitations':['Missing early historical price data prevents identifying the true monthly winner. This is an available-history illustration, not the requested complete universe.','Some holdings have no prices through the end date. Their last recorded value is carried forward; this does not establish actual merger consideration or bankruptcy recovery.','Adjusted-price total-return convention reinvests distributions in the original series. It does not separately retain spin-off shares or resolve stock-for-stock merger lineage.','Historical membership is a public reconstruction, not an official complete constituent file.','Fractional shares, dividend reinvestment, no taxes, trading fees or slippage. SPY historical fund expenses are embedded in its returns.']}
    for name,df in [('monthly_results.csv',monthly),('purchase_ledger.csv',l),('holdings.csv',holdings),('annual_results.csv',annual),('monthly_rankings.csv',pd.DataFrame(ranking_rows))]:df.to_csv(OUT/name,index=False,float_format='%.12g')
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2))
    (OUT/'unresolved_entries.json').write_text(json.dumps(unresolved,indent=2))
    # Independent lot-level valuation reconciles to aggregate holdings.
    assert abs(float(l.ending_marked_value.sum())-total)<0.01
    assert abs(float(l.spy_ending_value.sum())-benchmark)<0.01
    assert len(monthly)==346
    assert all(pd.to_datetime(l.signal_date)<pd.to_datetime(l.buy_date))
    if not saved:
        manifest={str(p.name):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'data'/'live_prices.parquet',ROOT/'data'/'live_membership_intervals.parquet']}
        (OUT/'source_hashes.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps(summary,indent=2),flush=True)
    print('\nLargest holdings\n'+holdings.head(15).to_string(index=False),flush=True)
    print('\nFirst purchases\n'+l.head(14).to_string(index=False),flush=True)
    print('\nCoverage\n'+annual[['year','mean_coverage','minimum_coverage']].to_string(index=False),flush=True)

if __name__=='__main__':main()
