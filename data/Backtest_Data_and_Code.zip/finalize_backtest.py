"""Final approximate backtest with user-authorized zero-value assumptions.

Uses frozen public input snapshots; no network or licensed-data dependency.
Missing ranking candidates are omitted. After a security's final quoted date,
its value becomes zero, even if it was acquired rather than bankrupt.
"""
from pathlib import Path
import json
import numpy as np,pandas as pd
from run_backtest import xirr
ROOT=Path(__file__).parent;INPUT=ROOT/'outputs/backtest_1998';OUT=ROOT/'outputs/final_backtest'
OUT.mkdir(parents=True,exist_ok=True)
START=pd.Period('1998-01',freq='M');ASOF=pd.Timestamp('2026-10-09');AMOUNT=1000.

def main():
    panel=pd.read_csv(INPUT/'price_endpoints.csv',parse_dates=['date'])
    marks=pd.read_csv(INPUT/'price_marks.csv',index_col=0,parse_dates=[0])
    last=pd.read_csv(INPUT/'terminal_quotes.csv',parse_dates=['date']).set_index('ticker')
    member=pd.read_csv(INPUT/'membership_intervals.csv',parse_dates=['start','end'])
    corrections=pd.read_csv(INPUT/'split_corrections.csv',parse_dates=['date'])
    # Remove extra total-return multipliers by raising all pre-event adjusted
    # prices. End prices stay on their existing basis. Actual splits with the
    # matching mechanical raw-price change are left untouched.
    for e in corrections.itertuples():
        factor=float(e.correction_factor);t=e.ticker;when=e.date
        mask=(panel.ticker==t)&(panel.date<when)
        panel.loc[mask,'adj_close']*=factor
        if t in marks:marks.loc[marks.index<when,t]*=factor
        if t in last.index and last.loc[t,'date']<when:last.loc[t,'adj_close']*=factor
    panel['adj_open']=panel.open*panel.adj_close/panel.close
    close=panel.pivot(index='date',columns='ticker',values='adj_close').sort_index()
    op=panel.pivot(index='date',columns='ticker',values='adj_open').sort_index()
    dates=panel[panel.ticker=='SPY'].date.sort_values().unique()
    calendar={m:(pd.Timestamp(ds.iloc[0]),pd.Timestamp(ds.iloc[-1])) for m,ds in pd.Series(pd.to_datetime(dates)).groupby(pd.Series(pd.to_datetime(dates)).dt.to_period('M'))}
    periods=pd.period_range(START,ASOF,freq='M')
    units=pd.Series(0.,index=close.columns);spy_units=0.;lots=[];monthly=[];rankings=[]
    firstbuy=calendar[START][0]
    for k,m in enumerate(periods):
        buy,end=calendar[m];signal=calendar[m-1][1];base=calendar[m-2][1]
        eligible=set(member[(member.start<=signal)&(member.end.isna()|(member.end>signal))].ticker)
        tickers=sorted(eligible&set(close.columns))
        returns=(close.loc[signal,tickers]/close.loc[base,tickers]-1).dropna().sort_values(ascending=False,kind='stable')
        chosen=str(returns.index[0]);entry=op.loc[buy,chosen]
        canprice=pd.notna(entry) and entry>0
        qty=AMOUNT/entry if canprice else 0.
        units[chosen]+=qty
        spentry=float(op.loc[buy,'SPY']);spy_units+=AMOUNT/spentry
        # Write off after the final recorded day, not on the buy day using
        # knowledge of future failure. The terminal value is always exactly 0.
        alive=(last.date.reindex(units.index)>=end)
        currentmarks=marks.loc[end].reindex(units.index).fillna(0).where(alive,0.)
        value=float((units*currentmarks).sum())
        benchmark=spy_units*float(close.loc[end,'SPY'])
        terminal_alive=last.loc[chosen,'date']>=ASOF and canprice
        finalprice=float(last.loc[chosen,'adj_close']) if terminal_alive else 0.
        finalvalue=qty*finalprice
        lot={'buy_date':str(buy.date()),'signal_date':str(signal.date()),'ticker':chosen,'previous_month_return':float(returns.iloc[0]),'entry_adj_open':float(entry) if canprice else 1.,'last_adj_close':finalprice,'raw_terminal_adj_close':float(last.loc[chosen,'adj_close']),'contribution':AMOUNT,'adjusted_units':qty,'ending_marked_value':finalvalue,'spy_entry_adj_open':spentry,'spy_final_adj_close':float(close.loc[ASOF,'SPY']),'spy_ending_value':AMOUNT*float(close.loc[ASOF,'SPY'])/spentry,'last_price_date':str(last.loc[chosen,'date'].date()),'status':'current price' if terminal_alive else 'written off ($0 rule)'}
        lots.append(lot)
        written_cost=sum(AMOUNT for x in lots if last.loc[x['ticker'],'date']<end or x['adjusted_units']==0)
        monthly.append({'date':str(end.date()),'buy_date':str(buy.date()),'winner':chosen,'previous_month_return':float(returns.iloc[0]),'members':len(eligible),'ranked_members':len(returns),'coverage':len(returns)/len(eligible),'missing_tickers':';'.join(sorted(eligible-set(returns.index))),'contribution':AMOUNT,'cumulative_contributions':AMOUNT*(k+1),'strategy_marked_value':value,'spy_value':benchmark,'stale_holdings_value':0.,'written_off_cost':written_cost})
        rankings.extend({'signal_date':str(signal.date()),'ticker':t,'rank':r+1,'total_return':float(ret)} for r,(t,ret) in enumerate(returns.items()))
    ledger=pd.DataFrame(lots);path=pd.DataFrame(monthly)
    holdings=ledger.groupby('ticker').agg(purchases=('contribution','size'),invested=('contribution','sum'),marked_value=('ending_marked_value','sum'),last_price_date=('last_price_date','max'),status=('status','first')).reset_index().sort_values('marked_value',ascending=False)
    total=float(ledger.ending_marked_value.sum());benchmark=float(ledger.spy_ending_value.sum());invested=len(ledger)*AMOUNT
    holdings['portfolio_weight']=holdings.marked_value/total
    annual=path.groupby(pd.to_datetime(path.date).dt.year).agg(total_invested=('cumulative_contributions','last'),strategy_marked_value=('strategy_marked_value','last'),spy_value=('spy_value','last'),mean_coverage=('coverage','mean'),written_off_cost=('written_off_cost','last')).reset_index().rename(columns={'date':'year'})
    zero=ledger.status.eq('written off ($0 rule)');top2=holdings[holdings.ticker.isin(['AAPL','NVDA'])].marked_value.sum()
    # A separate sensitivity writes off the ENTIRE deposit whenever any
    # candidate is missing. This is not a lower bound, just a harsher model.
    incomplete=path.coverage.lt(1).to_numpy()
    harsh=float(ledger.loc[~incomplete,'ending_marked_value'].sum())
    harshspy=float(ledger.loc[~incomplete,'spy_ending_value'].sum())
    comparison=pd.DataFrame([{'scenario':'Final: ended histories $0; observed leaders','strategy_value':total,'spy_value':benchmark,'total_contributed':invested},{'scenario':'Sensitivity: incomplete-ranking monthly deposit also $0','strategy_value':harsh,'spy_value':benchmark,'total_contributed':invested},{'scenario':'Matched complete-ranking months only (different contribution schedule)','strategy_value':harsh,'spy_value':harshspy,'total_contributed':float((~incomplete).sum()*AMOUNT)}])
    s={'status':'FINAL APPROXIMATE BACKTEST UNDER STATED ASSUMPTIONS','start':str(firstbuy.date()),'as_of':str(ASOF.date()),'monthly_contribution':AMOUNT,'purchases':len(ledger),'contributed':invested,'strategy_marked_value':total,'spy_value':benchmark,'strategy_profit':total-invested,'spy_profit':benchmark-invested,'strategy_xirr':xirr(list(ledger.buy_date)+[ASOF],[-AMOUNT]*len(ledger)+[total]),'spy_xirr':xirr(list(ledger.buy_date)+[ASOF],[-AMOUNT]*len(ledger)+[benchmark]),'value_multiple_vs_spy':total/benchmark,'stale_holdings_count':int(holdings.status.ne('current price').sum()),'writeoff_lots':int(zero.sum()),'writeoff_initial_cost':float(ledger.loc[zero,'contribution'].sum()),'top2_weight':float(top2/total),'top_holding':str(holdings.iloc[0].ticker),'top_holding_value':float(holdings.iloc[0].marked_value),'top_holding_weight':float(holdings.iloc[0].portfolio_weight),'winner_lots_below_cost':int((ledger.ending_marked_value<ledger.contribution).sum()),'winner_lots_beat_spy':int((ledger.ending_marked_value>ledger.spy_ending_value).sum()),'mean_price_coverage':float(path.coverage.mean()),'full_coverage_months':int((path.coverage==1).sum()),'missing_ranking_months':int((path.coverage<1).sum()),'split_corrections':len(corrections),'harsh_missing_ranking_value':harsh,'complete_months_only_spy_value':harshspy,'assumptions':['$1,000 new money each month; historical membership at signal month-end; rank total return; next-month first trading-day open; retain all purchases.','Any purchased security without a quote through October 9, 2026 is worth $0, including acquisitions and inaccessible histories. No merger recovery or successor stock is credited.','An unavailable candidate return is omitted from the ranking; the best observable eligible stock is selected. This remaining coverage assumption can materially change the result.','Obvious extra split multipliers are removed when adjusted returns include the recorded split but raw price does not show its mechanical change. This is a documented cleaning heuristic.','Fractional shares, reinvested distributions, no taxes or trading costs. SPY fees are embedded. In-kind spin-offs follow the provider adjusted-return convention.']}
    assert len(ledger)==346 and invested==346000
    assert abs(path.strategy_marked_value.iloc[-1]-total)<.01
    assert abs(path.spy_value.iloc[-1]-benchmark)<.01
    assert (ledger.loc[zero,'ending_marked_value']==0).all()
    assert (pd.to_datetime(ledger.buy_date)>pd.to_datetime(ledger.signal_date)).all()
    for name,df in [('purchase_ledger',ledger),('monthly_results',path),('holdings',holdings),('annual_results',annual),('monthly_rankings',pd.DataFrame(rankings)),('sensitivity',comparison),('split_corrections',corrections)]:df.to_csv(OUT/(name+'.csv'),index=False,float_format='%.12g')
    (OUT/'summary.json').write_text(json.dumps(s,indent=2))
    inputs={'summary':s,'sensitivity':json.loads(comparison.to_json(orient='records'))}
    for name,df in [('purchase_ledger',ledger),('monthly_results',path),('holdings',holdings),('annual_results',annual)]:inputs[name]=json.loads(df.to_json(orient='records'))
    (OUT/'workbook_inputs.json').write_text(json.dumps(inputs))
    print(json.dumps(s,indent=2));print(holdings.head(8).to_string(index=False));print(comparison.to_string(index=False))

if __name__=='__main__':main()
