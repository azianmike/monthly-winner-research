from pathlib import Path
import pandas as pd,numpy as np
from parquet_reader import read
root=Path(__file__).parent
p=read(root/'data/live_prices.parquet',['date','ticker','close','adj_close','stock_splits','source'])
p=p.sort_values(['ticker','date']);g=p.groupby('ticker',sort=False)
raw=p.close/g.close.shift();economic=p.adj_close/g.adj_close.shift();scale=economic/raw
split=p.stock_splits
next_raw=raw.groupby(p.ticker).shift(-1);next_scale=scale.groupby(p.ticker).shift(-1)
prev_raw=raw.groupby(p.ticker).shift(1);prev_scale=scale.groupby(p.ticker).shift(1)
# A correctly counted split recorded one day before/after the mechanical price
# change can create a large daily move which cancels the following day. Do not
# remove it unless the multiplier is actually duplicated or unpaired.
paired_next=(next_raw*split-1).abs().lt(.2)&(next_scale-1).abs().lt(.05)
paired_prev=(prev_raw*split-1).abs().lt(.2)&(prev_scale-1).abs().lt(.05)
mask=((split>=1.8)|(split<=.56)&(split>0))&raw.between(.85,1.2)&(scale/split-1).abs().lt(.025)&(scale-1).abs().gt(.3)&~paired_next&~paired_prev
f=p.loc[mask,['date','ticker','stock_splits','close','adj_close','source']].copy()
f['raw_price_ratio']=raw[mask];f['recorded_total_return']=economic[mask]-1
f['correction_factor']=split[mask]
f['reason']='Assume split factor applied although raw price did not show the mechanical split change.'
f.to_csv(root/'outputs/backtest_1998/split_corrections.csv',index=False)
print(f.to_string(index=False))
