FINAL APPROXIMATE BACKTEST UNDER USER-AUTHORIZED ASSUMPTIONS

January 2, 1998 through October 9, 2026. $1,000 new money monthly.
346 contributions; $346,000 invested. Never voluntarily sell a purchase.
Rank prior-month total returns among then-current S&P 500 members with usable
prices, buy at the following month's first trading-day open, and reinvest
distributions. Repeated winners get a fresh $1,000 investment.

FINAL RESULTS
Monthly winners: $8,204,466.91.
Matched monthly SPY purchases: $2,258,566.73.
Money-weighted annual returns: 17.84% vs 11.11%.
Every deposit and terminal value is included in the cash-flow IRR.

ZERO RULE
A bought company with no price through the terminal date is assigned $0,
including acquired, delisted, bankrupt and otherwise unavailable series.
No cash merger payout or successor stock is credited. Each affected purchase
loses the ENTIRE original $1,000, not merely the last recorded asset value.
113 purchase lots in 72 stocks are written off.
Initial cost of those lots: $113,000.
For the historical path the asset is written off after its final quoted date,
not retroactively at purchase using knowledge of a later disappearance.

REASONABLE DATA FALLBACKS
Unpriced candidates are omitted from ranking and the best observable eligible
stock is selected. This fallback is material: 235 of 346 rankings
are incomplete. The zero rule for BOUGHT companies does not recover the true
winner among missing candidates. This is a finalized approximation, not an
unbiased full-universe result or a guarantee of conservative overall returns.
Four apparent duplicate/unpaired split records were corrected by removing
the extra split multiplier. Proper mechanically reflected splits and merely
shifted adjacent-day events were retained. See split_corrections.csv.
Fractional shares, reinvested distributions, no taxes or trading costs. SPY
fund fees are embedded. In-kind spin-off returns follow provider adjustments.

ANALYSIS
Apple and Nvidia represent 71.4% of ending value. Only
95 of 346 lots beat their matched SPY deposits. Huge long-run winners
drive the portfolio, so this run does not establish broadly repeatable skill.

SENSITIVITY
The secondary model writes off the entire monthly deposit whenever ANY
candidate cannot be ranked. It ends at $419,574.46 versus the
same $2,258,566.73 SPY benchmark. This deliberately harsh assumption is a
stress test, not a bound on the true result. Another row uses only complete
ranking months with a matched smaller contribution schedule; do not compare
that row's dollar value with the original 346-deposit benchmark.

SOURCES
https://github.com/Johnbrick123/sp500-data/releases/tag/data
https://github.com/fja05680/sp500
The input snapshots were downloaded October 12, 2026 and end October 9, 2026.
Source and frozen-input hashes are retained. SPY, AAPL, NVDA and MU were
cross-checked with Yahoo history in the initial audit. No live data is required
to reproduce this final run.

REPRODUCE
Unzip, then run: python finalize_backtest.py
Requires numpy, pandas and scipy. Uses frozen inputs in outputs/backtest_1998
and regenerates final results in outputs/final_backtest. No network required.
run_backtest.py supports the earlier illustrative model; the finalized output
is produced by finalize_backtest.py. The workbook deposit input rescales the
fixed purchase ledger but does not rerank stocks when prices are changed.

VALIDATION
346 equal dated deposits, signals strictly before purchase, zero valuations
for every written-off purchase, and independent lot/portfolio/benchmark
reconciliation within one cent. Workbook formula and scaling checks are run
again for the finalized values. Frozen-input reproduction is tested separately.
