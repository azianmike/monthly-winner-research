from pathlib import Path
import json,zipfile,shutil
root=Path(__file__).parent;out=root/'outputs/final_backtest';source=root/'outputs/backtest_1998'
shutil.copyfile('/tmp/backtest-workbook/build.mjs',out/'build.mjs')
target=out/'Backtest_Data_and_Code.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    z.write(out/'README.txt','README.txt')
    for p in root.glob('*.py'):z.write(p,p.name)
    z.write(out/'build.mjs','build.mjs')
    for name in ['price_endpoints.csv','price_marks.csv','terminal_quotes.csv','membership_intervals.csv','split_corrections.csv','source_hashes.json','frozen_input_hashes.json','source_metadata.json','validation.json']:
        p=source/name
        if p.exists():z.write(p,str(p.relative_to(root)))
    for p in out.iterdir():
        if p.suffix in ['.csv','.json','.txt'] and p.name!='README.txt':z.write(p,str(p.relative_to(root)))
print('Final archive bytes:',target.stat().st_size)
