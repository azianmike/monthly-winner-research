import json,pathlib,urllib.request,concurrent.futures
root=pathlib.Path(__file__).parent/'data'
assets=json.loads((root/'live_release.json').read_text())['assets']
def get(a):
    p=root/('live_'+a['name'])
    if p.exists() and p.stat().st_size==a['size']:return
    with urllib.request.urlopen(urllib.request.Request(a['browser_download_url'],headers={'User-Agent':'historical-stock-backtest'}),timeout=60) as r,p.open('wb') as f:
        while True:
            b=r.read(1048576)
            if not b:break
            f.write(b)
    print(a['name'],p.stat().st_size,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    list(pool.map(get,[a for a in assets if a['name'] in ['prices.parquet','membership_intervals.parquet','members.parquet']]))
