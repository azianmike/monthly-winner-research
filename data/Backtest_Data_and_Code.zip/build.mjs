import fs from 'node:fs/promises';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const out=process.argv[2]||'/workspace/scratch/ab03f6d6c5d1/outputs/final_backtest';
const data=JSON.parse(await fs.readFile(`${out}/workbook_inputs.json`,'utf8'));
const wb=Workbook.create();
const summary=wb.worksheets.add('Summary');
const buys=wb.worksheets.add('Purchases');
const monthly=wb.worksheets.add('Monthly results');
const holdings=wb.worksheets.add('Holdings');
const sensitivity=wb.worksheets.add('Sensitivity');
const method=wb.worksheets.add('Method');
const navy='#233950',ink='#202b35',orange='#a45821',blue='#235a99';
const date=s=>new Date(`${s}T00:00:00Z`);
const fmtMoney='$#,##0;($#,##0);$0';
const n=data.purchase_ledger.length,last=n+6,nh=data.holdings.length,hlast=nh+6;
function base(sh,range){sh.showGridLines=false;sh.getRange(range).format.font={name:'Arial',size:10,color:ink};sh.getRange(range).format.rowHeight=22;sh.getRange(range).format.verticalAlignment='center';}
function header(sh,range){sh.getRange(range).format={fill:navy,font:{name:'Arial',size:10,bold:true,color:'#ffffff'},rowHeight:30,horizontalAlignment:'center',verticalAlignment:'center'};}
function title(sh,text,range){sh.getRange('A2').values=[[text]];sh.getRange('A2').format.font={name:'Arial',size:15,bold:true,color:navy};sh.getRange(range).format.borders={bottom:{style:'thin',color:'#b9c6d0'}};}
base(buys,`A1:O${last}`);title(buys,'Monthly purchases and final valuations','A3:O3');
buys.getRange('A4').values=[['Fixed selections from the finalized approximate run. Prices, contribution and lot valuations are visible below.']];
buys.getRange('A6:O6').values=[['Buy date','Signal date','Stock','Prior month return','Entry adj. open','Final adj. close','Contribution','Adjusted units','Final marked value','SPY entry','SPY final price','SPY final value','Valuation status','Final quote date','Difference vs SPY']];header(buys,'A6:O6');
const bv=data.purchase_ledger.map(x=>[date(x.buy_date),date(x.signal_date),x.ticker,x.previous_month_return,x.entry_adj_open,x.last_adj_close,null,null,null,x.spy_entry_adj_open,x.spy_final_adj_close,null,x.status,date(x.last_price_date),null]);
buys.getRange(`A7:O${last}`).values=bv;
buys.getRange(`G7:I${last}`).formulas=bv.map((_,i)=>{let r=i+7;return ["='Summary'!$C$18",`=G${r}/E${r}`,`=H${r}*F${r}`]});
buys.getRange(`L7:L${last}`).formulas=bv.map((_,i)=>{let r=i+7;return [`=G${r}*K${r}/J${r}`]});
buys.getRange(`O7:O${last}`).formulas=bv.map((_,i)=>{let r=i+7;return [`=I${r}-L${r}`]});
buys.getRange(`A7:B${last}`).setNumberFormat('mm/dd/yy');buys.getRange(`N7:N${last}`).setNumberFormat('mm/dd/yy');
buys.getRange(`D7:D${last}`).setNumberFormat('0.0%');buys.getRange(`E7:F${last}`).setNumberFormat('$0.0000');buys.getRange(`J7:K${last}`).setNumberFormat('$0.0000');
for(const c of ['G','I','L','O'])buys.getRange(`${c}7:${c}${last}`).setNumberFormat(fmtMoney);buys.getRange(`H7:H${last}`).setNumberFormat('0.0000');
buys.getRange(`A1:O${last}`).format.columnWidth=17;buys.getRange(`C1:C${last}`).format.columnWidth=20;buys.getRange(`M1:M${last}`).format.columnWidth=32;buys.getRange(`A6:O6`).format.wrapText=true;
buys.freezePanes.freezeRows(6);buys.freezePanes.freezeColumns(3);buys.tables.add(`A6:O${last}`,true,'PurchaseLedger');

base(monthly,`A1:N${last}`);title(monthly,'Monthly values and ranking coverage','A3:N3');
monthly.getRange('A4').values=[['Portfolio paths use the stored analysis per $1 monthly contribution. Full calculation inputs are in the reproduction archive.']];
monthly.getRange('A6:N6').values=[['Value date','Buy date','Observed winner','Total invested','Members','Ranked','Coverage','Leader mark','SPY value','Write-offs at cost','Leader value per $1','SPY value per $1','Write-off cost per $1','Month']];header(monthly,'A6:N6');
const mv=data.monthly_results.map(x=>[date(x.date),date(x.buy_date),x.winner,null,x.members,x.ranked_members,null,null,null,null,x.strategy_marked_value/1000,x.spy_value/1000,x.written_off_cost/1000,x.date.slice(0,7)]);
monthly.getRange(`A7:N${last}`).values=mv;
monthly.getRange(`D7:D${last}`).formulas=mv.map((_,i)=>[`=${i+1}*'Summary'!$C$18`]);
monthly.getRange(`G7:J${last}`).formulas=mv.map((_,i)=>{const r=i+7;return [`=F${r}/E${r}`,`=K${r}*'Summary'!$C$18`,`=L${r}*'Summary'!$C$18`,`=M${r}*'Summary'!$C$18`]});
monthly.getRange(`A7:B${last}`).setNumberFormat('mm/dd/yy');monthly.getRange(`G7:G${last}`).setNumberFormat('0.0%');for(const c of ['D','H','I','J'])monthly.getRange(`${c}7:${c}${last}`).setNumberFormat(fmtMoney);
monthly.getRange(`K7:M${last}`).setNumberFormat('0.0000');monthly.getRange(`A1:N${last}`).format.columnWidth=18;monthly.getRange(`C1:C${last}`).format.columnWidth=22;monthly.getRange(`A6:N6`).format.wrapText=true;
monthly.getRange(`G7:G${last}`).conditionalFormats.add('cellIs',{operator:'lessThan',formula:1,format:{fill:'#fff0dc',font:{color:'#8d4d1e'}}});
monthly.freezePanes.freezeRows(6);monthly.tables.add(`A6:N${last}`,true,'MonthlyPath');

base(holdings,`A1:G${hlast}`);title(holdings,'Holdings retained after purchase','A3:G3');
holdings.getRange('A4').values=[['Ended or unavailable histories are valued at $0, including acquired companies. No recovery is credited.']];
holdings.getRange('A6:G6').values=[['Stock','Purchases','Invested','Final marked value','Portfolio share','Valuation status','Final quote date']];header(holdings,'A6:G6');
holdings.getRange(`A7:G${hlast}`).values=data.holdings.map(x=>[x.ticker,null,null,null,null,x.status,date(x.last_price_date)]);
holdings.getRange(`B7:E${hlast}`).formulas=data.holdings.map((_,i)=>{const r=i+7;return [`=COUNTIFS('Purchases'!$C$7:$C$${last},A${r})`,`=SUMIFS('Purchases'!$G$7:$G$${last},'Purchases'!$C$7:$C$${last},A${r})`,`=SUMIFS('Purchases'!$I$7:$I$${last},'Purchases'!$C$7:$C$${last},A${r})`,`=D${r}/'Summary'!$C$10`]});
holdings.getRange(`C7:D${hlast}`).setNumberFormat(fmtMoney);holdings.getRange(`E7:E${hlast}`).setNumberFormat('0.0%');holdings.getRange(`G7:G${hlast}`).setNumberFormat('mm/dd/yy');
holdings.getRange(`A1:G${hlast}`).format.columnWidth=22;holdings.getRange(`F1:F${hlast}`).format.columnWidth=34;holdings.getRange('A6:G6').format.wrapText=true;holdings.freezePanes.freezeRows(6);holdings.tables.add(`A6:G${hlast}`,true,'RetainedHoldings');

base(summary,'A1:Q37');summary.tabColor=navy;summary.getRange('A1:Q37').format.columnWidth=13;summary.getRange('A1:A37').format.columnWidth=3;summary.getRange('B1:B37').format.columnWidth=35;summary.getRange('C1:D37').format.columnWidth=21;
summary.getRange('B2').values=[['Monthly winner strategy since 1998']];summary.getRange('B2').format.font={name:'Arial',size:15,bold:true,color:navy};summary.getRange('B3:Q3').format.borders={bottom:{style:'thin',color:'#b9c6d0'}};
summary.getRange('B5').values=[['Finalized approximation: ended histories valued at $0']];summary.getRange('B5').format.font={name:'Arial',size:11,bold:true,color:'#963824'};
summary.getRange('B7:D7').values=[['Metric','Observed leaders','S&P 500 via SPY']];header(summary,'B7:D7');
summary.getRange('B8:B12').values=[['Monthly deposit'],['Total contributions'],['Ending value'],['Investment gain'],['Money-weighted annual return']];
summary.getRange('C8:D12').formulas=[["=$C$18","=$C$18"],[`=SUM('Purchases'!G7:G${last})`,'=C9'],[`=SUM('Purchases'!I7:I${last})`,`=SUM('Purchases'!L7:L${last})`],['=C10-C9','=D10-D9'],['='+data.summary.strategy_xirr,'='+data.summary.spy_xirr]];
summary.getRange('C8:D11').setNumberFormat(fmtMoney);summary.getRange('C12:D12').setNumberFormat('0.0%');summary.getRange('B10:D10').format.font.bold=true;summary.getRange('C10').format.font.color=orange;summary.getRange('D10').format.font.color=blue;
summary.getRange('B14:B16').values=[['Months with incomplete ranking'],['Stocks valued at $0'],['Apple and Nvidia combined share']];
summary.getRange('C14').formulas=[[`=COUNTIFS('Monthly results'!G7:G${last},"<1")`]];
summary.getRange('C15').values=[[data.summary.stale_holdings_count]];
summary.getRange('C16').formulas=[[`=(SUMIFS('Holdings'!D7:D${hlast},'Holdings'!A7:A${hlast},"NVDA")+SUMIFS('Holdings'!D7:D${hlast},'Holdings'!A7:A${hlast},"AAPL"))/C10`]];summary.getRange('C16').setNumberFormat('0.0%');
summary.getRange('B17').values=[['Write-off purchases (initial cost)']];summary.getRange('C17').values=[[data.summary.writeoff_initial_cost]];summary.getRange('C17').setNumberFormat(fmtMoney);
summary.getRange('B18').values=[['Monthly contribution (editable)']];summary.getRange('C18').values=[[1000]];summary.getRange('C18').format.fill='#fff1cd';summary.getRange('C18').format.font.color='#235a99';summary.getRange('C18').setNumberFormat(fmtMoney);
summary.getRange('B19:B20').values=[['First purchase'],['End of analysis']];summary.getRange('C19:C20').values=[[date(data.purchase_ledger[0].buy_date)],[date(data.summary.as_of)]];summary.getRange('C19:C20').setNumberFormat('mm/dd/yy');
summary.getRange('B22').values=[['Largest holdings in the finalized model']];summary.getRange('B22').format.font.bold=true;summary.getRange('B23:D23').values=[['Stock','Marked value','Share']];header(summary,'B23:D23');
summary.getRange('B24:D31').formulas=data.holdings.slice(0,8).map((_,i)=>[`='Holdings'!A${i+7}`,`='Holdings'!D${i+7}`,`='Holdings'!E${i+7}`]);summary.getRange('C24:C31').setNumberFormat(fmtMoney);summary.getRange('D24:D31').setNumberFormat('0.0%');
summary.getRange('B34').values=[['Early price gaps can change the stock selected each month.']];summary.getRange('B35').values=[['Ended histories are written off at $0. Extra split multipliers were corrected under documented assumptions.']];summary.getRange('B36').values=[['Missing candidates are omitted from rankings, so this is an approximate historical-universe test.']];summary.getRange('B34:Q36').format.font={name:'Arial',size:10,color:'#963824'};
const chart=summary.charts.add('line',[monthly.getRange(`N6:N${last}`),monthly.getRange(`H6:H${last}`),monthly.getRange(`I6:I${last}`)]);
chart.title='Portfolio values under the $0 rule';chart.titleTextStyle.typeface='Arial';chart.titleTextStyle.fontSize=14;chart.setPosition('G7','Q31');chart.legend={position:'bottom',textStyle:{typeface:'Arial',fontSize:10}};chart.xAxis={axisType:'textAxis',tickLabelInterval:48,textStyle:{typeface:'Arial',fontSize:9}};chart.yAxis={numberFormatCode:'$0.0,,"M"',numberFormatSourceLinked:false,textStyle:{typeface:'Arial',fontSize:10}};chart.series.items[0].fill=orange;chart.series.items[1].fill=blue;

base(sensitivity,'A1:D15');title(sensitivity,'Sensitivity to missing ranking history','A3:D3');
sensitivity.getRange('A1:A15').format.columnWidth=85;sensitivity.getRange('B1:D15').format.columnWidth=25;
sensitivity.getRange('A5').values=[['The second row deliberately writes off every unverifiable monthly selection. It is a stress test, not a lower bound.']];
sensitivity.getRange('A7:D7').values=[['Scenario','Strategy ending value','SPY ending value','Total contributed']];header(sensitivity,'A7:D7');
sensitivity.getRange('A8:D10').values=data.sensitivity.map(x=>[x.scenario,null,null,null]);
sensitivity.getRange('B8:D10').formulas=data.sensitivity.map(x=>[`=${x.strategy_value}/1000*'Summary'!$C$18`,`=${x.spy_value}/1000*'Summary'!$C$18`,`=${x.total_contributed}/1000*'Summary'!$C$18`]);
sensitivity.getRange('B8:D10').setNumberFormat(fmtMoney);
sensitivity.getRange('A12').values=[['Row 3 uses only 111 complete-ranking months, so both portfolios receive fewer deposits. Compare within that row.']];
base(method,'A1:C39');title(method,'Method, data sources and limits','A3:C3');method.getRange('A1:A39').format.columnWidth=31;method.getRange('B1:B39').format.columnWidth=108;
const notes=[
['Interpretation','$1,000 of NEW money every month. No discretionary sales. Historical S&P 500 member pool. January 1998 through October 9, 2026.'],
['Ranking','Prior calendar-month total return. Membership on the prior month’s last trading day. Stocks need prices at both month-end endpoints. Missing stocks are omitted, so the true winner may differ.'],
['Purchase timing','First trading-day open of the next month, after the signal is known. Adjusted open = open × adjusted close / close. No same-month or month-end execution using information not yet known.'],
['Holding convention','Adjusted-price total-return units with fractional shares and reinvested distributions. Stocks stay in the portfolio after leaving the index. Repeated winners receive another $1,000.'],
['Benchmark','SPY total-return history, bought with identical cash amounts on identical dates. This is an investable S&P 500 proxy after embedded fund expenses.'],
['Costs','No personal taxes, commissions or bid/ask slippage. Fractional shares assumed available throughout the period.'],
['Early coverage','Mean ranked-member coverage is 54.1% in 1998, 60.9% in 2000 and 89.6% in 2008. Only 111 of 346 months have complete endpoint-price coverage in this public dataset.'],
['Unavailable ending prices','User rule: a bought security without a quote through October 9, 2026 is worth $0. Its entire $1,000 purchase is lost. This includes acquired companies and inaccessible histories; no merger payout or successor stock is credited. See Holdings and Purchases for every write-off.'],
['Corporate actions','Reinvested distributions follow the adjusted-price convention. Inaccessible successor stocks and acquired-company series are assigned $0 under the user rule. Spin-off returns use the provider convention rather than a separate child-share ledger.'],
['Apparent split errors','Extra split factors were removed when raw prices did not show the mechanical split move and no offsetting adjacent-day event explained it. Four records are documented in split_corrections.csv, including USB and PBG. Monthly winners were reranked after cleaning.'],
['Checks performed','Exact 346 contributions, all signal dates before purchase dates, no duplicate input date/ticker keys, positive price inputs. Lot totals reconcile to aggregate portfolio and SPY totals to within one cent.'],
['Price checks','Direct Yahoo history reproduces raw closes for SPY, Apple, Nvidia and Micron. Their cumulative total-return factors agree within 0.00006%. This checks those series only and does not validate all stocks.'],
['Return measure','Money-weighted annual return uses every dated contribution and terminal marked value. Ending value / total contributions is not a CAGR.'],
['Editable contribution','Changing Summary C18 scales the fixed purchase ledger and valuation paths. Historical picks stay fixed. This workbook does not refresh quotes or rerank stocks when source prices are edited.'],
['Remaining limitation','Unobservable candidate returns are omitted from selection. Writing off purchased unavailable histories does not resolve missing candidate stocks. A complete licensed universe could change picks and outcomes. The requested approximate model is finalized under this explicit fallback.'],
['Source: public prices','https://github.com/Johnbrick123/sp500-data/releases/tag/data — downloaded October 12, 2026. Dates through October 9, 2026. Source hashes and complete calculation inputs are in the reproduction archive.'],
['Source: membership','Public dataset membership_intervals.parquet, reconstructed from https://github.com/fja05680/sp500 and S&P index announcements. This is not an official complete member file.'],
['Source: benchmark','https://www.ssga.com/us/en/intermediary/etfs/state-street-spdr-sp-500-etf-trust-spy and the public price archive.'],
['Source: definitive dataset','https://indexes.morningstar.com/research-data-products/crsp-us-stock-databases — daily/monthly active and inactive security data, permanent IDs and corporate actions.'],
['Reproduction','The ZIP contains Python source, month-end and entry prices, every ranked stock each month, constituent intervals, purchase ledger, coverage, source hashes and quality issues. No extra Python packages are needed beyond the stated bundled analysis libraries.']
];
method.getRange(`A6:B${notes.length+5}`).values=notes;method.getRange(`B6:B${notes.length+5}`).format.wrapText=true;method.getRange(`A6:A${notes.length+5}`).format.font.bold=true;method.getRange(`A6:B${notes.length+5}`).format.autofitRows();method.getRange(`A6:B${notes.length+5}`).format.verticalAlignment='top';

wb.recalculate();
const value=summary.getRange('C10:D10').values[0];if(Math.abs(value[0]-data.summary.strategy_marked_value)>.01||Math.abs(value[1]-data.summary.spy_value)>.01)throw Error('Headline does not reconcile');
summary.getRange('C18').values=[[2000]];wb.recalculate();const doubled=summary.getRange('C10:D10').values[0];if(Math.abs(doubled[0]-2*value[0])>.01||Math.abs(doubled[1]-2*value[1])>.01)throw Error('Editable contribution does not recalculate');summary.getRange('C18').values=[[1000]];wb.recalculate();
console.log((await wb.inspect({kind:'table',range:'Summary!B7:D20',include:'values,formulas',tableMaxRows:14,tableMaxCols:3,maxChars:1800})).ndjson);
console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!',options:{useRegex:true,maxResults:10},summary:'Formula errors',maxChars:500})).ndjson);
for(const [sheetName,range]of [['Summary','B2:Q36'],['Purchases','A2:O13'],['Monthly results','A2:N13'],['Holdings','A2:G13'],['Sensitivity','A2:D12'],['Method','A2:B15']]){const image=await wb.render({sheetName,range,scale:1.5,format:'png'});await fs.writeFile(`${out}/preview_${sheetName.replaceAll(' ','_')}.png`,new Uint8Array(await image.arrayBuffer()));}
await(await SpreadsheetFile.exportXlsx(wb)).save(`${out}/Monthly_Winner_Backtest_1998.xlsx`);
console.log('Exported workbook; headline and contribution recalculation verified.');
